# OCSSD-R

Code in this folder mainly focuses on providing block device interfaces on Open-Channel SSDs.
The kernel release is based on **4.17-rc1**, pblk module of which is modified by SMI programmers from Taiwan Province.
