#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xa69ba1fd, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x9ef8c70c, __VMLINUX_SYMBOL_STR(kobject_put) },
	{ 0xccb0ba6a, __VMLINUX_SYMBOL_STR(alloc_pages_current) },
	{ 0x53326531, __VMLINUX_SYMBOL_STR(mempool_alloc_pages) },
	{ 0x19c500f4, __VMLINUX_SYMBOL_STR(wait_for_completion_io_timeout) },
	{ 0x405e4ae7, __VMLINUX_SYMBOL_STR(kmem_cache_destroy) },
	{ 0x5069ed07, __VMLINUX_SYMBOL_STR(fs_bio_set) },
	{ 0x7ea21d2d, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0x88eee7aa, __VMLINUX_SYMBOL_STR(kobject_get) },
	{ 0xd2b09ce5, __VMLINUX_SYMBOL_STR(__kmalloc) },
	{ 0x9573f6ee, __VMLINUX_SYMBOL_STR(nvm_set_tgt_bb_tbl) },
	{ 0x778de4b5, __VMLINUX_SYMBOL_STR(nvm_get_chunk_meta) },
	{ 0xc8fdd8b0, __VMLINUX_SYMBOL_STR(bio_alloc_bioset) },
	{ 0xa80aba54, __VMLINUX_SYMBOL_STR(nvm_register_tgt_type) },
	{ 0xd6ee688f, __VMLINUX_SYMBOL_STR(vmalloc) },
	{ 0xce31b8a1, __VMLINUX_SYMBOL_STR(pv_lock_ops) },
	{ 0xc76c458b, __VMLINUX_SYMBOL_STR(del_timer) },
	{ 0xb9919689, __VMLINUX_SYMBOL_STR(blk_queue_max_hw_sectors) },
	{ 0x43a53735, __VMLINUX_SYMBOL_STR(__alloc_workqueue_key) },
	{ 0xca454c7e, __VMLINUX_SYMBOL_STR(generic_end_io_acct) },
	{ 0xa5239ca2, __VMLINUX_SYMBOL_STR(kobject_uevent) },
	{ 0xc0a3d105, __VMLINUX_SYMBOL_STR(find_next_bit) },
	{ 0xe49259e9, __VMLINUX_SYMBOL_STR(blk_queue_split) },
	{ 0xad27f361, __VMLINUX_SYMBOL_STR(__warn_printk) },
	{ 0x4e536271, __VMLINUX_SYMBOL_STR(__dynamic_pr_debug) },
	{ 0x1e88e240, __VMLINUX_SYMBOL_STR(mempool_destroy) },
	{ 0xe4f742fb, __VMLINUX_SYMBOL_STR(init_timer_key) },
	{ 0x8becc996, __VMLINUX_SYMBOL_STR(bio_advance) },
	{ 0x47e42031, __VMLINUX_SYMBOL_STR(kobject_del) },
	{ 0x999e8297, __VMLINUX_SYMBOL_STR(vfree) },
	{ 0xa8c8fb29, __VMLINUX_SYMBOL_STR(nvm_get_tgt_bb_tbl) },
	{ 0xb348a850, __VMLINUX_SYMBOL_STR(ex_handler_refcount) },
	{ 0x1ac5d3cb, __VMLINUX_SYMBOL_STR(strcspn) },
	{ 0x97651e6c, __VMLINUX_SYMBOL_STR(vmemmap_base) },
	{ 0x922f45a6, __VMLINUX_SYMBOL_STR(__bitmap_clear) },
	{ 0x78b705f3, __VMLINUX_SYMBOL_STR(kthread_create_on_node) },
	{ 0x15ba50a6, __VMLINUX_SYMBOL_STR(jiffies) },
	{ 0x3d7c4918, __VMLINUX_SYMBOL_STR(nvm_submit_io_sync) },
	{ 0x19ad6985, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0x183fa88b, __VMLINUX_SYMBOL_STR(mempool_alloc_slab) },
	{ 0xa084749a, __VMLINUX_SYMBOL_STR(__bitmap_or) },
	{ 0x8173aace, __VMLINUX_SYMBOL_STR(nvm_dev_dma_free) },
	{ 0xfac4bd1e, __VMLINUX_SYMBOL_STR(del_timer_sync) },
	{ 0xfb578fc5, __VMLINUX_SYMBOL_STR(memset) },
	{ 0x1916e38c, __VMLINUX_SYMBOL_STR(_raw_spin_unlock_irqrestore) },
	{ 0x6b47d9e1, __VMLINUX_SYMBOL_STR(current_task) },
	{ 0xf9b2a6f, __VMLINUX_SYMBOL_STR(down_trylock) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0xd6266fa8, __VMLINUX_SYMBOL_STR(kthread_stop) },
	{ 0xe1537255, __VMLINUX_SYMBOL_STR(__list_del_entry_valid) },
	{ 0xed3d37b6, __VMLINUX_SYMBOL_STR(blk_queue_max_discard_sectors) },
	{ 0xaf954cb9, __VMLINUX_SYMBOL_STR(bio_add_page) },
	{  0x49d47, __VMLINUX_SYMBOL_STR(kobject_init_and_add) },
	{ 0x4c9d28b0, __VMLINUX_SYMBOL_STR(phys_base) },
	{ 0xacb7c8a4, __VMLINUX_SYMBOL_STR(bio_clone_fast) },
	{ 0x479c3c86, __VMLINUX_SYMBOL_STR(find_next_zero_bit) },
	{ 0xd985dc99, __VMLINUX_SYMBOL_STR(mempool_free_pages) },
	{ 0x93a6e0b2, __VMLINUX_SYMBOL_STR(io_schedule) },
	{ 0x393d4de9, __VMLINUX_SYMBOL_STR(crc32_le) },
	{ 0x8c03d20c, __VMLINUX_SYMBOL_STR(destroy_workqueue) },
	{ 0x4226c0c9, __VMLINUX_SYMBOL_STR(mod_timer) },
	{ 0x926ae64c, __VMLINUX_SYMBOL_STR(nvm_submit_io) },
	{ 0x8a99a016, __VMLINUX_SYMBOL_STR(mempool_free_slab) },
	{ 0x57c74fb8, __VMLINUX_SYMBOL_STR(up_write) },
	{ 0x7ff7214d, __VMLINUX_SYMBOL_STR(generic_start_io_acct) },
	{ 0xb3453cc2, __VMLINUX_SYMBOL_STR(down_write) },
	{ 0x68f31cbd, __VMLINUX_SYMBOL_STR(__list_add_valid) },
	{ 0x42160169, __VMLINUX_SYMBOL_STR(flush_workqueue) },
	{ 0x8f29ef39, __VMLINUX_SYMBOL_STR(bio_endio) },
	{ 0xd757043f, __VMLINUX_SYMBOL_STR(bio_put) },
	{ 0x9f46ced8, __VMLINUX_SYMBOL_STR(__sw_hweight64) },
	{ 0xf11543ff, __VMLINUX_SYMBOL_STR(find_first_zero_bit) },
	{ 0x615911d7, __VMLINUX_SYMBOL_STR(__bitmap_set) },
	{ 0x7cd8d75e, __VMLINUX_SYMBOL_STR(page_offset_base) },
	{ 0x40a9b349, __VMLINUX_SYMBOL_STR(vzalloc) },
	{ 0x8ff4079b, __VMLINUX_SYMBOL_STR(pv_irq_ops) },
	{ 0x7f42c0fb, __VMLINUX_SYMBOL_STR(mempool_alloc) },
	{ 0xcf077ec5, __VMLINUX_SYMBOL_STR(blk_queue_flag_set) },
	{ 0x12a38747, __VMLINUX_SYMBOL_STR(usleep_range) },
	{ 0xbe75ee29, __VMLINUX_SYMBOL_STR(bio_map_kern) },
	{ 0xdb7305a1, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0x1000e51, __VMLINUX_SYMBOL_STR(schedule) },
	{ 0xc9d4fb1e, __VMLINUX_SYMBOL_STR(mempool_create) },
	{ 0x27fac315, __VMLINUX_SYMBOL_STR(bioset_create) },
	{ 0xe5815f8a, __VMLINUX_SYMBOL_STR(_raw_spin_lock_irq) },
	{ 0x90edb2cb, __VMLINUX_SYMBOL_STR(nvm_unregister_tgt_type) },
	{ 0x52a28d10, __VMLINUX_SYMBOL_STR(wake_up_process) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
	{ 0xf2e6490e, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_trace) },
	{ 0xf1279b8e, __VMLINUX_SYMBOL_STR(mempool_free) },
	{ 0xe259ae9e, __VMLINUX_SYMBOL_STR(_raw_spin_lock) },
	{ 0x680ec266, __VMLINUX_SYMBOL_STR(_raw_spin_lock_irqsave) },
	{ 0xb2675a9, __VMLINUX_SYMBOL_STR(kmem_cache_create) },
	{ 0x4302d0eb, __VMLINUX_SYMBOL_STR(free_pages) },
	{ 0xb3f7646e, __VMLINUX_SYMBOL_STR(kthread_should_stop) },
	{ 0x63ebcd34, __VMLINUX_SYMBOL_STR(blk_queue_write_cache) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0xa46f2f1b, __VMLINUX_SYMBOL_STR(kstrtouint) },
	{ 0x69acdf38, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0xc678e4da, __VMLINUX_SYMBOL_STR(nvm_bb_tbl_fold) },
	{ 0x78e739aa, __VMLINUX_SYMBOL_STR(up) },
	{ 0x4ca9669f, __VMLINUX_SYMBOL_STR(scnprintf) },
	{ 0x6c3f70e0, __VMLINUX_SYMBOL_STR(guid_gen) },
	{ 0xb352177e, __VMLINUX_SYMBOL_STR(find_first_bit) },
	{ 0x63c4d61f, __VMLINUX_SYMBOL_STR(__bitmap_weight) },
	{ 0x3b644591, __VMLINUX_SYMBOL_STR(__bitmap_shift_left) },
	{ 0x2e0d2f7f, __VMLINUX_SYMBOL_STR(queue_work_on) },
	{ 0x4610aee6, __VMLINUX_SYMBOL_STR(complete) },
	{ 0x28318305, __VMLINUX_SYMBOL_STR(snprintf) },
	{ 0xf3d7f81, __VMLINUX_SYMBOL_STR(vmalloc_to_page) },
	{ 0x6d7ab639, __VMLINUX_SYMBOL_STR(bio_add_pc_page) },
	{ 0x13758a69, __VMLINUX_SYMBOL_STR(blk_queue_logical_block_size) },
	{ 0xbf41b9a8, __VMLINUX_SYMBOL_STR(bioset_free) },
	{ 0xfbd7168c, __VMLINUX_SYMBOL_STR(down_timeout) },
	{ 0x22f314b1, __VMLINUX_SYMBOL_STR(nvm_dev_dma_alloc) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "9C3B7DDF10D00A15CB2B2B6");
