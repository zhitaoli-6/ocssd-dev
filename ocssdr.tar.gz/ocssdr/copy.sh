linux_dir=linux-4.17-rc1_ocssd_test_2

cp lightnvm.h /home/sirius/$linux_dir/include/linux/.
cp common.h /home/sirius/$linux_dir/drivers/lightnvm/.
cp core.c /home/sirius/$linux_dir/drivers/lightnvm/.
