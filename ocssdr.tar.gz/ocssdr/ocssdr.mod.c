#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xa69ba1fd, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x90edb2cb, __VMLINUX_SYMBOL_STR(nvm_unregister_tgt_type) },
	{ 0xbf41b9a8, __VMLINUX_SYMBOL_STR(bioset_free) },
	{ 0xa80aba54, __VMLINUX_SYMBOL_STR(nvm_register_tgt_type) },
	{ 0x27fac315, __VMLINUX_SYMBOL_STR(bioset_create) },
	{ 0xf2e6490e, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_trace) },
	{ 0x7ea21d2d, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0x13758a69, __VMLINUX_SYMBOL_STR(blk_queue_logical_block_size) },
	{ 0x8e312a4a, __VMLINUX_SYMBOL_STR(generic_make_request) },
	{ 0xb663aac, __VMLINUX_SYMBOL_STR(bio_chain) },
	{ 0xed4e7c1b, __VMLINUX_SYMBOL_STR(bio_split) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "DC157C15586EFF17CDA3BF7");
